users=[]
class User:
    def __init__(self,usuario,senha,tipo):
        self.usuario=usuario
        self.senha=senha
        self.tipo=tipo
def adicionar_user(user):
        users.append(user)
admin1=User("igor","20","admin")
user1=User("Vini","20","user")
adicionar_user(admin1)
adicionar_user(user1)


#----------
import mysql.connector

db_connection = mysql.connector.connect(
    host="localhost",
    user="root",
    password="Gui967612938//",
    database="witchwiki"
)
cursor = db_connection.cursor(dictionary=True)
cursor=db_connection.cursor()
def Exibirtabelas():
 lista_tabelas=[]
 sql="SHOW TABLES"
 cursor.execute(sql)
 tabelas=cursor.fetchall()
 for tabela in tabelas:
        lista_tabelas.append(tabela)
 return lista_tabelas
    
def exibirColunas(nomedatabela):
        lista_colunas=[]
        sql=f"SHOW COLUMNS FROM {nomedatabela}"
        cursor.execute(sql)
        colunas=cursor.fetchall()
        for coluna in colunas:
                lista_colunas.append(coluna)
        return lista_colunas
def adicionar_raca(nome,regiao):
     sql="INSERT INTO raça (nomeRaca,regiao) VALUES(%s,%s)"
     valores=(nome,regiao)
     cursor.execute(sql,valores)
     db_connection.commit()
def apagar_elemento(id,nomedatabela):
    sql = f"DELETE FROM {nomedatabela} WHERE idraça = %s"
    valores = (id,)
    cursor.execute(sql,valores)
    db_connection.commit()
