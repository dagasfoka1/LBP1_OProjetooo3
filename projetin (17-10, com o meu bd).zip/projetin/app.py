from flask import Flask
from controllers.controller1 import Capao

app=Flask(__name__)
app.secret_key= "30"

app.register_blueprint(Capao)

if "__main__"==__name__:
    app.run(debug=True)
    


