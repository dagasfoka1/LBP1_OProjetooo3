users=[]
class User:
    def __init__(self,usuario,senha,tipo):
        self.usuario=usuario
        self.senha=senha
        self.tipo=tipo
def adicionar_user(user):
        users.append(user)
admin1=User("igor","20","admin")
user1=User("Vini","20","user")
adicionar_user(admin1)
adicionar_user(user1)