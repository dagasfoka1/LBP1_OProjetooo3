from flask import Flask,Blueprint,render_template,request, redirect, url_for,session,g
from models.model1 import users,adicionar_user, User

Capao=Blueprint("Capao",__name__)

@Capao.before_request
def before_request():
    g.message = "Conexão ao servidor está funcionando!"

@Capao.after_request
def after_request(response):
    print(g.message)  
    print(response.status, response.status_code)
    return response

@Capao.route("/")
def Welcome():
    if "username" in session:
        texto=f"Bem vindo {session['username']}"
        return render_template("index1.html",texto=texto, tipo=session["tipo"])
    return render_template("index1.html",texto="Você não está logado")

@Capao.route("/tela-login",methods=["POST","GET"])
def tela_login():
    session.pop("username",None)
    session.pop("senha", None)
    session.pop("tipo", None)
    if request.method=="GET":
        return render_template("login.html")
    
@Capao.route("/login", methods=["POST"])
def login():
    if request.method=="POST":
        session.permanent=True
        user=request.form['user']
        senha=request.form['senha']
        for usuario in users:
            if  user == usuario.usuario:
                if senha == usuario.senha:
                    session["username"]=user
                    session["senha"]=senha
                    session["tipo"]=usuario.tipo
                    return redirect(url_for("Capao.Welcome"))
    return redirect(url_for("Capao.Welcome"))

@Capao.route("/logout")
def logout():
    session.pop("username",None)
    session.pop("senha", None)
    session.pop("tipo", None)
    return redirect(url_for("Capao.Welcome"))

@Capao.route("/add",methods=["POST","GET"])
def add():
    if request.method=="GET":
        return render_template("addUser.html")
    if request.method=="POST":
        user=request.form["user"]
        senha=request.form["senha"]
        tipo=request.form["tipo"]
        usuario=User(user,senha,tipo)
        adicionar_user(usuario)
        return redirect(url_for("Capao.Welcome"))