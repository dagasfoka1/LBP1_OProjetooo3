from flask import Flask,Blueprint,render_template,request, redirect, url_for,session
from models.model1 import users,adicionar_user, User,admin1

Capao=Blueprint("Capao",__name__)

@Capao.route("/")
def Welcome():
    if "username" in session:
        texto="Bem vindo {session[username]}"
        return render_template("index1.html",texto=texto)
    elif "admin" in session:
        texto="Bem vindo {session[admin]}"
        return render_template("index1.html",texto=texto)
    return render_template("index1.html",texto="Você não está logado")

@Capao.route("/tela-login",methods=["POST","GET"])
def tela_login():
    if request.method=="GET":
        return render_template("login.html")
    
@Capao.route("/login", methods=["POST"])
def login():
    if request.method=="POST":
        usuario=request.form['user']
        senha=request.form['senha']
        print(usuario)
        print(senha)
        for u in users:
            if  usuario == u.usuario:
                if senha == u.senha:
                    return "logado"
    return "não logou"
                
