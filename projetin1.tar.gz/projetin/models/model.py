Levantamentos=["A","C","B"]
def AddLevantamentos(num):
    if num=="1":
        Levantamentos.append("A")
        print(num)
    if num=="2":
        Levantamentos.append("B")
    if num=="3":
        Levantamentos.append("C")
def ContarLevantamentos():
    listaL=[]
    A = Levantamentos.count("A") 
    C = Levantamentos.count("C")
    B = Levantamentos.count("B")
    listaL.extend([A,B,C])
    return listaL