users=[]
lista_frutas=[]
contador=0
class User:
    def __init__(self,usuario,senha,tipo,id):
        self.usuario=usuario
        self.senha=senha
        self.tipo=tipo
        self.id=id
class Fruta:
    def __init__(self, nome, preco, id):
        self.nome=nome
        self.preco=preco
        self.id=id
def gerar_id_unico():
    global contador
    contador += 1
    return contador
def adicionar_user(user,senha,tipo):
        usuario=User(user,senha,tipo,gerar_id_unico())
        users.append(usuario)
adicionar_user("igor","20","admin")
adicionar_user("Vini","20","user")
#---------