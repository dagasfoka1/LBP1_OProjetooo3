from flask import Flask,Blueprint,render_template,request, redirect, url_for
from models.model import AddLevantamentos,ContarLevantamentos

Capao=Blueprint("Capao",__name__)
texto="Capão levanta muito"
@Capao.route("/")
def Welcome():
    return render_template("index.html", texto=texto)
@Capao.route("/add",methods=["POST","GET"])
def VerL():
    if (request.method=="POST"):
        num=request.form["L"]
        AddLevantamentos(num)
        return redirect(url_for("Capao.Welcome"))
    if request.method=="GET":
        listaL=ContarLevantamentos()
        return render_template("levantamentos.html", texto=texto, listaL=listaL)

