from flask import Flask
from controllers.controller import Capao
app=Flask(__name__)
app.register_blueprint(Capao)
if "__main__"==__name__:
    app.run(debug=True)