from flask import Flask,Blueprint,render_template,request, redirect, url_for,session,g, make_response,flash
from models.modelLogin import users,adicionar_user
import json
Capao=Blueprint("Capao",__name__)
rotas_publicas=["Capao.tela_login","Capao.Welcome","Capao.login"]
@Capao.before_request
def before_request():
    g.message = "Conexão ao servidor está funcionando!"
    #cookieLogin = request.cookies.get("dadosLogin")
    #cookieLoginDados = json.loads(cookieLogin) if cookieLogin else None
    print(request.endpoint)
    if (request.endpoint == "Capao.tela_login" or request.endpoint=="Capao.login") and "username" in session:
        return redirect(url_for("Capao.Welcome"))
    if request.endpoint == "Capao_login" and "username" not in session:
        return redirect(url_for("Capao.tela_login"))
    if request.endpoint in rotas_publicas:
        return
    if "username" not in session:
        return redirect(url_for("Capao.tela_login"))


@Capao.after_request
def after_request(response):
    print(g.message)  
    print(response.status, response.status_code)
    return response

@Capao.route("/")
def Welcome():
    #cookieLogin_str = request.cookies.get("dadosLogin")
    #cookieLogin = json.loads(cookieLogin_str) if cookieLogin_str else None
    if "username" in session:
        texto = f"Bem vindo {session['username']}"
        return render_template("indexLogin.html", texto=texto, tipo=session['tipo'])
    return render_template("indexLogin.html", texto="Você não está logado", tipo="")

@Capao.route("/tela-login",methods=["POST","GET"])
def tela_login():
    if request.method=="GET":
        return render_template("login.html")
    
@Capao.route("/login", methods=["POST"])
def login():
    if request.method=="POST":
        session.permanent=True
        user=request.form['user']
        senha=request.form['senha']
        for usuario in users:
            if  user == usuario.usuario:
                if senha == usuario.senha:
                    session["username"]=user
                    session["id"]=usuario.id
                    session["tipo"]=usuario.tipo
                    #response=make_response(redirect(url_for("Capao.Welcome")))
                    #user_data = {"usuario": usuario.usuario, "tipo": usuario.tipo, "id": usuario.id}
                    #response.set_cookie("dadosLogin",json.dumps(user_data),max_age=60*60*24)
                    #return response
                    return redirect(url_for("Capao.Welcome"))
        flash("Falha no login", "error")
        return redirect(url_for("Capao.tela_login"))

@Capao.route("/logout")
def logout():
    session.pop("username",None)
    session.pop("tipo", None)
    session.pop("id",None)
    #response= make_response(redirect(url_for("Capao.Welcome")))
    #response.set_cookie("dadosLogin","", expires=0)
    #return response
    return redirect(url_for("Capao.Welcome"))
@Capao.route("/add", methods=["POST", "GET"])
def add():
    #cookieLogin_str = request.cookies.get("dadosLogin")
    #cookieLogin = json.loads(cookieLogin_str) if cookieLogin_str else None
    if request.method == "GET":
            return render_template("addUser.html")
    elif request.method == "POST":
        user = request.form["user"]
        senha = request.form["senha"]
        tipo = request.form["tipo"]
        adicionar_user(user, senha, tipo)
        return redirect(url_for("Capao.Welcome"))
    return "lixo"

        #fazer pagina de erro
        
# @Capao.route("/VerTabela")
# def VerTabela():
#     #tabelas=Exibirtabelas()
#     #return render_template("dados.html", tabelas=tabelas)
#     return
# @Capao.route("/VerColuna")
# def VerTabela():
#     tipo=1
#     #tabelas=Exibirtabelas()
#     #return render_template("dados.html", tabelas=tabelas, tipo=tipo)
#     return