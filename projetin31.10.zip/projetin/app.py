from flask import Flask,render_template
from controllers.controllerLogin import Capao

app=Flask(__name__)
app.secret_key= "30"

app.register_blueprint(Capao)

@app.errorhandler(404)
def error404(e):
    return render_template("error404.html"),404

if "__main__"==__name__:
    app.run(debug=True)
    


